# Senior AI/ML Engineer — Take Home Assignment

Thanks for taking the time to tackle this assignment! We hope you enjoy working on it!

**Expected time: up to 2 hours.** Please don't spend more. A focused, well-reasoned submission beats an exhaustive one. It's fine (encouraged, even) to leave things undone and note what you'd do next.

## The problem

Attached are two files:

- `patients.csv` — a synthetic dataset inspired by the kind of data we work with at Metriport. Each row is a patient with demographics, encounter history, conditions, and utilization data. The target column is `hospitalized_next_year` (whether the patient had an inpatient admission in the following 12 months).
- `patients_to_score.csv` — 5,000 patients in the same format, without the target column.

**Your task: build a model that predicts the likelihood of hospitalization in the next year for a new patient, tell us how good it is, and deliver risk scores for every patient in `patients_to_score.csv`.**

This mirrors a real problem we solve for customers: care teams use these predictions to prioritize outreach to high-risk patients.

## What to submit

A zip containing:

1. **Your code** — notebook and/or scripts, whatever you'd actually use. It should run end-to-end and regenerate your scores file (include a `requirements.txt` and the one command that regenerates your scores).
2. **Your scores** — a CSV with two columns, `patient_id` and `risk_score` (higher = riskier), covering every patient in `patients_to_score.csv`.
3. **A short write-up** (half a page is fine; bullets are fine) covering:
   - What you found in the data and what you did about it
   - Your modeling approach and why
   - How you evaluated it, with the numbers — include AUC-ROC on your held-out data, alongside whichever other metrics you think matter for this problem
   - How you'd explain what this model does, and how good it is, to a customer's care team (non-ML audience)

## Ground rules

- Python preferred. Any standard libraries are fine.
- **Use whatever tools you'd use on the job, including AI assistants.** In your write-up, add two or three lines on what you used them for. We're not grading how much you used them.
- Don't build a UI, don't deploy anything, don't over-engineer.
- **Don't spend time tuning hyperparameters** — defaults are fine.
- The data is fully synthetic — no real patient information.

Questions? Reach out to us via email or Slack. See you soon!
